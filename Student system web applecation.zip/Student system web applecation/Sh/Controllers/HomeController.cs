﻿using Microsoft.AspNetCore.Mvc;

namespace Sh.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
