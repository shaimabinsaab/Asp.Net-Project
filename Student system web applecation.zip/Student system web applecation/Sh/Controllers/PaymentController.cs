﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Sh.Model.Reposetories;
using Sh.Model;
using Sh.Viewmodels;
using IHostingEnvironment = Microsoft.AspNetCore.Hosting.IHostingEnvironment;

namespace Sh.Controllers
{
    public class PaymentController : Controller
    {
        private readonly IPublicReposetories<Payment> PublicReposetories;
        private readonly IPublicReposetories<Customer> CustomerRepostiry;
        private readonly IHostingEnvironment hosting;

        // GET: PaymentController
        public PaymentController(IPublicReposetories<Payment> PublicReposetories, IPublicReposetories<Customer> CustomerRepostiry, IHostingEnvironment hosting)
        {
            this.PublicReposetories = PublicReposetories;
            this.CustomerRepostiry = CustomerRepostiry;
            this.hosting = hosting;
        }
        public ActionResult Index()
        {

            var payment = PublicReposetories.GetAll();
            return View(payment);
        }

        // GET: PaymentController/Details/5
        public ActionResult Details(int id)
        {
            var payment = PublicReposetories.GetById(id);
            return View(payment);
        }

        // GET: PaymentController/Create
        public ActionResult Create()
        {
            Viewmodel model = new Viewmodel
            {
                Customer = FillSelectCustomer()
            };
           

            return View(model);
        }

        // POST: PaymentController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Viewmodel model)
        {
            try
            {
                string filename = string.Empty;
                if (model.File != null)
                {
                    string image = Path.Combine(hosting.WebRootPath, "image");
                    filename = model.File.FileName;
                    string fullPath = Path.Combine(image, filename);
                    model.File.CopyTo(new FileStream(fullPath, FileMode.Create));
                }
                if (model.CustomerId == -1)
                {
                    ViewData["errorMessage"] = "Please Select Customer!";
                    model = new Viewmodel
                    {
                        Customer = FillSelectCustomer()
                    };

                    return View(model);
                }
                Customer customer = CustomerRepostiry.GetById(model.CustomerId);
                Payment payment = new Payment
                {

                    Id = model.PaymentId,
                    Price = model.PaymentPrice,
                    Customer = customer,
                    ImgUrl = filename


                };
                PublicReposetories.Add(payment);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: PaymentController/Edit/5
        public ActionResult Edit(int id)
        {
            Payment payment = PublicReposetories.GetById(id);
            var CustomerId = payment.Customer == null ? 0 : payment.Customer.Id;
            Viewmodel model = new Viewmodel
            {
                PaymentId = payment.Id,
                PaymentPrice = payment.Price,
                CustomerId = payment.Customer.Id,
                Customer = CustomerRepostiry.GetAll().ToList()
            };

            return View(model);
        }

        // POST: PaymentController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Viewmodel nmodel)
        {
            try
            {

                Payment payment = new Payment
                {
                    Id = nmodel.PaymentId,
                    Price = nmodel.PaymentPrice,
                    Customer = CustomerRepostiry.GetById(nmodel.CustomerId)
                };

                PublicReposetories.Update(id, payment);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: PaymentController/Delete/5
        public ActionResult Delete(int id)
        {

            var payment = PublicReposetories.GetById(id);
            return View(payment);
        }

        // POST: PaymentController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, Payment price)
        {
            try
            {

                price = PublicReposetories.GetById(id);
                PublicReposetories.Delete(price);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        public List <Customer> FillSelectCustomer()
        {
            List<Customer> Customer = CustomerRepostiry.GetAll().ToList();
            Customer.Insert(0, new Customer { Id = -1, Name = "--Please Select Customer Name--" });
            return Customer;
        }

        public ActionResult Search(string key)
        {
            var result = PublicReposetories.search(key);
            return View("Index", result);


        }

    }
}
