﻿namespace Sh.Model
{
    public class Payment {
        public int Id { get; set; }
        public int Price { get; set; }
        public Customer Customer { get; set; }
        public string ImgUrl { get; set; }
    }
}
