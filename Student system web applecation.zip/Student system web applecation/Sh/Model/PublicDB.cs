﻿using Microsoft.EntityFrameworkCore;

namespace Sh.Model
{
    public class PublicDB:DbContext
    {
        public PublicDB(DbContextOptions<PublicDB> option) : base(option) { } 
        public DbSet<Customer> customers { get; set; }
        public DbSet<Payment> Payment { get; set; }
    }
        
}
