﻿using Microsoft.EntityFrameworkCore;

namespace Sh.Model.Reposetories
{
    public class DbCustomerrepositry: IPublicReposetories<Customer>
    {
        PublicDB db;
        public DbCustomerrepositry(PublicDB db)
        {
           this.db = db;

            
        }

        public void Add(Customer entity)
        {
            db.customers.Add(entity);
            db.SaveChanges();
        }

        public void Delete(Customer entity)
        {
            db.customers.Remove(entity);
            db.SaveChanges();

        }

        public IList<Customer> GetAll()
        {
            return db.customers.ToList();
        }

        public Customer GetById(int id)
        {
            var customer = db.customers.SingleOrDefault(x => x.Id == id);
            return customer;
        }

        public IList<Customer> search(string key)
        {
            throw new NotImplementedException();
        }

        

        public void Update(int id, Customer entity)
        {
           db.Update(entity);
            db.SaveChanges();

        }
    }
}

