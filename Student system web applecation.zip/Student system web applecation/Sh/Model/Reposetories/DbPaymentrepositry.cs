﻿using Microsoft.EntityFrameworkCore;

namespace Sh.Model.Reposetories
{
    public class DbPaymentrepositry : IPublicReposetories<Payment>
    {

        PublicDB db;

        public DbPaymentrepositry(PublicDB db)
        {
            this.db = db;
        }
        public void Add(Payment entity)

        {
                db.Payment.Add(entity);
                db.SaveChanges();
        }

        public void Delete(Payment entity)
        {
            db.Payment.Remove(entity);
            db.SaveChanges();
        }

        public IList<Payment> GetAll()
        {
            return db.Payment.Include(a=>a.Customer).ToList();
        }

        public Payment GetById(int id)
        {
            var Payment = db.Payment.Include(a => a.Customer).SingleOrDefault(x => x.Id == id);
            return Payment;
        }

        public IList<Payment> search(string key)
        {
            var Payment = db.Payment.Include(a => a.Customer).Where(p =>p.Customer.Name.Contains(key)).ToList();
            return Payment;
        }

        public void Update(int id, Payment entity)
        {
            db.Update(entity);
            db.SaveChanges();
        }
    }
}
