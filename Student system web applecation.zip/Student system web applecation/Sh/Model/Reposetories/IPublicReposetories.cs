﻿namespace Sh.Model.Reposetories
{
    public interface IPublicReposetories<X>
    {

        IList<X> GetAll();
        X GetById(int id);
        void Add(X entity);
        void Update(int id, X entity);
        void Delete(X entity);
        IList<X> search (string key);
    }
}
