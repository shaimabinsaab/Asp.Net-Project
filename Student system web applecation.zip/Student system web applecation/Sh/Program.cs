using Sh.Model;
using Sh.Model.Reposetories;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();
builder.Services.AddMvc();
builder.Services.AddScoped<IPublicReposetories<Customer>, DbCustomerrepositry>();
builder.Services.AddScoped<IPublicReposetories<Payment>, DbPaymentrepositry>();
builder.Services.AddDbContext<PublicDB>(opts =>
opts.UseSqlServer(connectionString: builder.Configuration.GetConnectionString(name: "mymodel"))
);

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Customer}/{action=Index}/{id?}");

app.UseAuthorization();

app.MapRazorPages();

app.Run();

