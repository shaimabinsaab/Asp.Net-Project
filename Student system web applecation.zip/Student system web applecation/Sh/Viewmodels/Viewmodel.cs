﻿using Sh.Model;

namespace Sh.Viewmodels
{
    public class Viewmodel
    {
        public int PaymentId { get; set; }
        public int PaymentPrice { get; set; }
        public string ImgUrl { get; set; }
        public int CustomerId { get; set; }
        public List<Customer> Customer { get; set; }
        public IFormFile File { get; set; } 
    }
}
